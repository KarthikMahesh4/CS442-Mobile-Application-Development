package mahesh.karthik.com.newsgateway_a20383027;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> sourceList = new ArrayList<>();
    private ArrayList<String> categoryList = new ArrayList<>();
    private ArrayList<NewsArticles> articleList = new ArrayList<>();
    static Adapter pageAdapter;
    static List<Fragment> fragments;
    static ViewPager pager;
    private ArrayList<String> items = new ArrayList<>();
    private Menu menu;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private DrawerLayout drawerLayout;
    private ListView listView;
    private Receiver newsReceiver;
    private Boolean flag = false;
    static Context ctx;
   // static ArrayList newsArticles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ctx =this;
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        listView = (ListView) findViewById(R.id.left_drawer);
        listView.setAdapter(new ArrayAdapter<>(this, R.layout.drawer_list_item, items));
        listView.setOnItemClickListener(new ListView.OnItemClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pager.setBackground(null);
                onSelect(position);
            }
        });

        actionBarDrawerToggle = new ActionBarDrawerToggle(
                this,
                drawerLayout,
                R.string.open_navigation_drawer,
                R.string.close_navigation_drawer
        );

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        fragments = new ArrayList<Fragment>();
        pageAdapter = new Adapter(getSupportFragmentManager());
        pager = (ViewPager) findViewById(R.id.viewpager);
        pager.setAdapter(pageAdapter);
        pager.setBackgroundResource(R.drawable.news_main);
        Intent serviceIntent = new Intent(MainActivity.this, MyService.class);
        startService(serviceIntent);
        newsReceiver = new Receiver();
        IntentFilter filter = new IntentFilter("ACTION_NEWS_STORY");
        registerReceiver(newsReceiver, filter);

        new GetNewsSource(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "all");
    }

    public void loadSource(ArrayList<String> s, ArrayList<String> c) {

        sourceList.clear();
        categoryList.clear();
        sourceList = s;
        categoryList = c;
        Collections.sort(categoryList);
        if (flag == false) {
            for (int i = 0; i < categoryList.size(); i++) {
                menu.add(R.menu.menu_main, Menu.NONE, 0, categoryList.get(i));
            }
            flag = true;
        }
        listView.setAdapter(new ArrayAdapter<>(this,
                R.layout.drawer_list_item, sourceList));

    }


    static void reloadFragments(ArrayList<NewsArticles> aList) {

        for (int i = 0; i < pageAdapter.getCount(); i++) {
            pageAdapter.notifyChangeInPosition(i);
        }
        fragments.clear();

        for (int i = 0; i < aList.size(); i++) {

            fragments.add(ViewPagerFragment.createInstance(aList.get(i)));

        }

        pageAdapter.notifyDataSetChanged();
        pager.setCurrentItem(0);
    }

    private void onSelect(int position) {

        items = sourceList;
        setTitle(items.get(position));
        String src = items.get(position).toLowerCase();
        Intent intent = new Intent();
        intent.setAction("ACTION_MSG_TO_SERVICE");
        intent.putExtra("DATA_EXTRA1", src);
        sendBroadcast(intent);
        drawerLayout.closeDrawer(listView);
    }

    private class Adapter extends FragmentPagerAdapter {
        private long baseId = 0;

        public Adapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Override
        public long getItemId(int position) {
            return baseId + position;
        }

        public void notifyChangeInPosition(int n) {

            baseId += getCount() + n;
        }

    }

    class Receiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("ACTION_NEWS_STORY")) {
                if (intent.hasExtra(MyService.SERVICE_DATA)) {
                    String stringExtra=intent.getStringExtra(MyService.SERVICE_DATA);
                    articleList = new Gson().fromJson(stringExtra, new TypeToken<List<NewsArticles>>(){}.getType());
                    reloadFragments(articleList);
                }
            }
        }
    }

    @Override
    protected void onDestroy() {unregisterReceiver(newsReceiver);
        Intent intent = new Intent(MainActivity.this, MyService.class);
        stopService(intent);
        super.onDestroy();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        actionBarDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        actionBarDrawerToggle.onConfigurationChanged(newConfig);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        this.menu = menu;
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        if (item.toString().equals("all")) {
            new GetNewsSource(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "all");
        } else {
            new GetNewsSource(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "Category", item.toString());
        }
        return true;
    }
}
