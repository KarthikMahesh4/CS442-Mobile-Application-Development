package mahesh.karthik.com.newsgateway_a20383027;

/**
 * Created by Karthik on 14/4/2018.
 */

import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;


public class GetNewsSource extends AsyncTask<String, Void, String> {

    private ArrayList<String> sourceList = new ArrayList<>();
    private MainActivity mainActivity;
    private final String URL = "https://newsapi.org/v1/sources?language=en&country=us";
    private final String APIKey = "219fcdc1b7c34fc3b5bc4022756bab98";
    private ArrayList<String> source = new ArrayList<>();
    private ArrayList<String> category = new ArrayList<>();
    private String getCategory = "";

    public GetNewsSource(MainActivity ma) {
        mainActivity = ma;
    }

    @Override
    protected void onPostExecute(String s) {
        mainActivity.loadSource(source, category);
    }

    @Override
    protected String doInBackground(String... params) {
        if (params[0].equals("Category")) {
            getCategory = params[1];
            Uri.Builder buildURL = Uri.parse(URL).buildUpon();
            buildURL.appendQueryParameter("category", getCategory);
            buildURL.appendQueryParameter("apikey", APIKey);
            String stringUrl = buildURL.build().toString();
            StringBuilder sb = new StringBuilder();
            try {
                URL url = new URL(stringUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
            } catch (Exception e) {
                return null;
            }
            parseJSON(sb.toString());
        } else {
            Uri.Builder buildURL = Uri.parse(URL).buildUpon();
            buildURL.appendQueryParameter("apikey", APIKey);
            String stringUrl = buildURL.build().toString();
            StringBuilder sb = new StringBuilder();
            try {
                URL url = new URL(stringUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
            } catch (Exception e) {
                return null;
            }
            parseJSON(sb.toString());
        }
        return null;
    }

    private void parseJSON(String s) {
        try {
            JSONObject stock = new JSONObject(s);
            JSONArray sourceList = (JSONArray) stock.get("sources");
            for (int i = 0; i < sourceList.length(); i++) {
                this.sourceList.add(sourceList.getString(i));
                JSONObject j = new JSONObject(this.sourceList.get(i));
                source.add(j.getString("name"));
                if (!(category.contains(j.getString("category"))))
                    category.add(j.getString("category"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}