package mahesh.karthik.com.newsgateway_a20383027;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

import com.google.gson.Gson;
import java.util.ArrayList;

/**
 * Created by Karthik on 14/4/2018.
 */

public class MyService extends Service {

    private boolean running = true;
    private Receiver sReceiver;
    static ArrayList<NewsArticles> newsArticles = new ArrayList<>();
    static final String SERVICE_DATA = "SERVICE_DATA";

    public MyService() {

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        sReceiver = new Receiver();
        IntentFilter filter2 = new IntentFilter("ACTION_MSG_TO_SERVICE");
        registerReceiver(sReceiver, filter2);

        new Thread(new Runnable() {
            @Override
            public void run() {

                while (running) {
                    if (newsArticles.isEmpty()) {
                        try {
                            Thread.sleep(250);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Intent intent1 = new Intent();
                        intent1.setAction("ACTION_NEWS_STORY");
                        intent1.putExtra(SERVICE_DATA, new Gson().toJson(newsArticles).toString());
                        sendBroadcast(intent1);
                        newsArticles.clear();
                    }


                }

            }
        }).start();

        return Service.START_STICKY; 
    }

    public void loadArticle(ArrayList<NewsArticles> d) {
        newsArticles.clear();
        newsArticles.addAll(d);
        if (d.size() == 0) {
            MainActivity.reloadFragments(newsArticles);
            Toast.makeText(MainActivity.ctx.getApplicationContext(),"No Articles available",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    class Receiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("ACTION_MSG_TO_SERVICE")) {
                if (intent.hasExtra("DATA_EXTRA1")) {
                    String source = intent.getStringExtra("DATA_EXTRA1");
                    source = source.replaceAll("\\s", "");
                    new GetNewsArticle(MyService.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, source);

                }
            }
        }
    }
}
