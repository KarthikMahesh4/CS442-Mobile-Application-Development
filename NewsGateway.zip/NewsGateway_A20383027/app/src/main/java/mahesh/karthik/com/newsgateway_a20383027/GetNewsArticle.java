package mahesh.karthik.com.newsgateway_a20383027;

/**
 * Created by Karthik on 14/4/2018.
 */

import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;


public class GetNewsArticle extends AsyncTask<String, Void, String> {

    private MyService articleService;
    private final String NEWS_API = "https://newsapi.org/v1/articles?";
    private final String API_KEY = "219fcdc1b7c34fc3b5bc4022756bab98";
    private ArrayList<String> articleList =new ArrayList<>();
    public ArrayList<NewsArticles> newsArticles = new ArrayList<>();


    public GetNewsArticle(MyService ms) {
        articleService = ms;
    }

    @Override
    protected void onPostExecute(String s) {

        articleService.loadArticle(newsArticles);
    }

    @Override
    protected String doInBackground(String... params) {

        String source = params[0];

        Uri.Builder buildURL = Uri.parse(NEWS_API).buildUpon();
        buildURL.appendQueryParameter("source", source);
        buildURL.appendQueryParameter("apiKey", API_KEY);

        String stringUrl = buildURL.build().toString();

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(stringUrl);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }


        } catch (Exception e) {
            newsArticles=new ArrayList<>();
            return null;
        }
        parseJSON(sb.toString());
        return null;
    }

    private void parseJSON(String s) {
        try {
            JSONObject stock = new JSONObject(s);
            JSONArray articles = (JSONArray) stock.get("articles");
            newsArticles=new ArrayList<>();
            for (int i = 0; i < articles.length(); i++) {
                articleList.add(articles.getString(i));
                JSONObject data = new JSONObject(articleList.get(i));
                NewsArticles art=new NewsArticles();

                art.setTitle(data.getString("title"));
                art.setAuthorName(data.getString("author"));
                art.setDescription(data.getString("description"));
                art.setImageURL(data.getString("urlToImage"));
                art.setUrl(data.getString("url"));
                art.setTime(data.getString("publishedAt"));
                art.setCurrentPage(i+1);
                art.setTotalPage(articles.length());
                newsArticles.add(art);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
