package mahesh.karthik.com.newsgateway_a20383027;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Picasso;
import android.view.View.OnClickListener;
import static android.provider.AlarmClock.EXTRA_MESSAGE;

/**
 * Created by Karthik on 14/4/2018.
 */

public class ViewPagerFragment extends Fragment implements OnClickListener  {

    NewsArticles articles;

    public static final ViewPagerFragment createInstance(NewsArticles message) {
        ViewPagerFragment f = new ViewPagerFragment();
        Bundle bdl = new Bundle(1);
        bdl.putString(EXTRA_MESSAGE, new Gson().toJson(message));

        f.setArguments(bdl);

        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        String message = getArguments().getString(EXTRA_MESSAGE);
        articles=new Gson().fromJson(message, new TypeToken<NewsArticles>(){}.getType());
        View v = inflater.inflate(R.layout.myfragment_layout, container, false);
        TextView author= v.findViewById(R.id.author);
        TextView title= v.findViewById(R.id.articleTitle);
        TextView description= v.findViewById(R.id.description);
        TextView pageNo= v.findViewById(R.id.pageNo);
        ImageView imageURL= v.findViewById(R.id.imageURL);
        TextView date = v.findViewById(R.id.date);
        author.setText(articles.getAuthorName());
        title.setText(articles.getTitle());
        description.setText(articles.getDescription());
        date.setText(articles.getTime());
        Picasso.with(getContext()).load(articles.getImageURL()).into(imageURL);
        author.setOnClickListener(this);
        pageNo.setText(articles.getCurrentPage()+" of " +articles.getTotalPage());
        imageURL.setOnClickListener(this);
        title.setOnClickListener(this);
        description.setOnClickListener(this);
        return v;
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(articles.getUrl()));
        startActivity(intent);
    }
}
